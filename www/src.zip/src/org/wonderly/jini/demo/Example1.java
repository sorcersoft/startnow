package org.wonderly.jini.demo;

import org.wonderly.jini.*;
import java.rmi.*;

public class Example1 extends PersistentJiniService {
	public Example1() throws RemoteException {
	}
}