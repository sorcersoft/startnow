package org.wonderly.util.jini2;

import javax.swing.*;

public interface JMenuBarFactory {
	public JMenuBar getJMenuBar();
}
