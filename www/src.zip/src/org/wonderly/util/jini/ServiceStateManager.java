package org.wonderly.util.jini;

/**
 *  @author <a href="mailto:gregg.wonderly@pobox.com">Gregg Wonderly</a>.
 */
public interface ServiceStateManager {
	public void deactivate();
}
